-- Leaked by Poseidon Leaks
-- https://discord.gg/poseidon-leaks
TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

ESX.RegisterUsableItem('switch', function(source) 
    TriggerClientEvent('stg_switch:use', source)
end)

RegisterCommand("switch", function(source, args, rawCommand)
    TriggerClientEvent('stg_switch:use', source)
end, true) -- set this to false to allow anyone.